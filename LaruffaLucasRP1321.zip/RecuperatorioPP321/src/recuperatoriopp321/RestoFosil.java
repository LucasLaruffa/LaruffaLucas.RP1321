
package recuperatoriopp321;

import java.time.LocalDate;


public class RestoFosil extends Hallazgo implements Analizable {
    private final String especieDescubierta;
    private final boolean isCompleto;

    public RestoFosil(String sitioHallazgo, LocalDate fechaDescubrimiento, int estadoConservacion,String especieDescubierta, boolean isCompleto) {
        super(sitioHallazgo, fechaDescubrimiento, estadoConservacion);
        validarEspecie(especieDescubierta);
        this.especieDescubierta = especieDescubierta;
        this.isCompleto = isCompleto;
    }

    @Override
    public String analizar() {
        StringBuilder sb = new StringBuilder();
        sb.append(especieDescubierta).append(" SIENDO ANALIZADA. \n");
        return sb.toString();
    }

    @Override
    public String toString() {
        String completo = (isCompleto) ? "EL FOSIL ESTA COMPLETO\n" : "EL FOSIL ESTA INCOMPLETO\n";
        StringBuilder sb = new StringBuilder();
        sb.append(super.toString()).append(" ESTE ES UN FOSIL DE ").append(especieDescubierta).append(". ").append(completo).append("\n");

        return sb.toString();
    }
    
    private void validarEspecie(String especie){
        if(especie == null){
            throw new IllegalArgumentException("LA ESPECIE " + especieDescubierta + " SE CARGO INCORRECTAMENTE");
        }
    }
    
    
    
    
}
