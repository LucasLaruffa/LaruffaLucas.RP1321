
package recuperatoriopp321;


public enum EpocaHistorica {
    PRECOLOMBINA,
    COLONIAL,
    MODERNA;
    
}
