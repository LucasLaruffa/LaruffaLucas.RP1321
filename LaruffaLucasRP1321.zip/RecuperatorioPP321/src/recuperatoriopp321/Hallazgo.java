package recuperatoriopp321;

import java.time.LocalDate;
import java.util.Objects;

public abstract class Hallazgo {

    private final String sitioHallazgo;
    private final LocalDate fechaDescubrimiento;
    private final int estadoConservacion;
    private static int id = 50000;
    private final int idHallazgo;
    private static final int MIN_CONSERVACION = 0;
    private static final int MAX_CONSERVACION = 10;

    public Hallazgo(String sitioHallazgo, LocalDate fechaDescubrimiento, int estadoConservacion) {
        validarSitio(sitioHallazgo);
        validarConservacion(estadoConservacion);
        validarFecha(fechaDescubrimiento);
        this.sitioHallazgo = sitioHallazgo;
        this.fechaDescubrimiento = fechaDescubrimiento;
        this.estadoConservacion = estadoConservacion;
        this.idHallazgo = id++;
    }

    private void validarSitio(String sitio) {
        if (sitio == null) {
            throw new IllegalArgumentException("El hallazgo " + idHallazgo + " Se cargo con sitio invalido");
        }
        
    }
    private void validarConservacion(int conservacion){
        if (conservacion < MIN_CONSERVACION || conservacion > MAX_CONSERVACION){
            throw new IllegalArgumentException("El hallazgo " + idHallazgo + " Se cargo con conservaion Invalida");
        }
    }
    
    private void validarFecha(LocalDate fecha){
        if(fecha == null){
            throw new IllegalArgumentException("El hallazgo " + idHallazgo + " Se cargo con fecha invalida");
        }
    }

    @Override
    public int hashCode() {

        return Objects.hash(sitioHallazgo, fechaDescubrimiento, estadoConservacion);
    }

    @Override
    public boolean equals(Object o) {
        if (o == null || !(o instanceof Hallazgo h)){
            return false;
        }
        return this.sitioHallazgo.equals(h.sitioHallazgo) && this.fechaDescubrimiento.equals(h.fechaDescubrimiento);
    }

    @Override
    public String toString() {
        StringBuilder sb = new StringBuilder();
        sb.append("ID DE HALLAZGO ").append(idHallazgo).append(". ENCONTRADO EN ").append(sitioHallazgo).append(" CON FECHA ").append(fechaDescubrimiento).append(". SU CONSERVACION ES NIVEL ").append(estadoConservacion).append(". ");

        return sb.toString();
    }

    public int getEstadoConservacion() {
        return estadoConservacion;
    }
    
    
    
    

}
