
package recuperatoriopp321;


public interface Restaurable {
    String restaurar();
    String getEpocaHistorica();
}
