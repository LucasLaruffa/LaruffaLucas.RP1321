
package recuperatoriopp321;

public enum TipoEdificacion {
    TEMPLO,
    VIVIENDA;
}
