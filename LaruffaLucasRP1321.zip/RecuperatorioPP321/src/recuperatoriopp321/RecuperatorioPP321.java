package recuperatoriopp321;

import java.time.LocalDate;
import java.time.Month;

public class RecuperatorioPP321 {

    public static void main(String[] args) {

        SistemaGestionArqueologico sis1 = new SistemaGestionArqueologico("SISTEMA 1");
        RestoFosil r1 = new RestoFosil("PERU", LocalDate.of(1997, Month.MARCH, 25), 5, "T-REX", true);
        RestoFosil r2 = new RestoFosil("PERU", LocalDate.of(1997, Month.MARCH, 25), 5, "T-REX", false);
        HerramientaAntigua h1 = new HerramientaAntigua("ARGENTINA", LocalDate.of(2003, Month.FEBRUARY, 17), 3, "COBRE", 3);
        ConstruccionRuinosa c1 = new ConstruccionRuinosa("COLOMBIA", LocalDate.of(2017, Month.MARCH, 6), 8, TipoEdificacion.TEMPLO, EpocaHistorica.PRECOLOMBINA);
        try {
            sis1.registrarHallazgo(r1);
            //sis1.registrarHallazgo(r2);
            sis1.registrarHallazgo(h1);
            sis1.registrarHallazgo(c1);

            System.out.println(sis1.mostrarHallazgos());
            System.out.println("++++++++++++++++++++++++++++++++");
            System.out.println(sis1.ejecutarAnalisis());
            System.out.println("++++++++++++++++++++++++++++++++");
            System.out.println(sis1.restaurarHallazgos());
            System.out.println("++++++++++++++++++++++++++++++++");
            System.out.println(sis1.filtrarPorEpoca(EpocaHistorica.PRECOLOMBINA));
            System.out.println("++++++++++++++++++++++++++++++++");
            System.out.println(sis1.mostrarPorConservacion(2, 5));

        } catch (HallazgoExistenteException e) {
            System.out.println(e.getMessage());
        } catch (IllegalArgumentException e) {
            System.out.println(e.getMessage());
        }
    }

}
