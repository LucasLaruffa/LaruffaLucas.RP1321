
package recuperatoriopp321;

/**
 *
 * @author Otro
 */
public class HallazgoExistenteException extends RuntimeException {
    private static final String MENSAJE = "EL HALLAZGO YA SE ENCUENTRA DENTRO DEL SISTEMA";
    public HallazgoExistenteException() {
        this(MENSAJE);
    }
    
    public HallazgoExistenteException(String mensaje){
        super(mensaje);
    }
    


}