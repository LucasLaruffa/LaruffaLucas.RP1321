
package recuperatoriopp321;

import java.time.LocalDate;


public class ConstruccionRuinosa extends Hallazgo implements Restaurable{
    private TipoEdificacion tipoEdificacion;
    private EpocaHistorica epocaHistorica;

    public ConstruccionRuinosa( String sitioHallazgo, LocalDate fechaDescubrimiento, int estadoConservacion,TipoEdificacion tipoEdificacion, EpocaHistorica epocaHistorica) {
        super(sitioHallazgo, fechaDescubrimiento, estadoConservacion);
        this.tipoEdificacion = tipoEdificacion;
        this.epocaHistorica = epocaHistorica;
    }

    @Override
    public String restaurar() {
        StringBuilder sb = new StringBuilder();
        sb.append("LA ").append(tipoEdificacion).append(" DE LA EPOCA ").append(epocaHistorica).append(", SE ENCUENTRA SIENDO RESTAURADA \n");
        return sb.toString();
    }

    @Override
    public String toString() {
        StringBuilder sb = new StringBuilder();
        sb.append(super.toString()).append(" ESTA CONSTRUCCION ES UNA ").append(tipoEdificacion).append(" QUE DATA DE LA EPOCA ").append(epocaHistorica).append("\n");
        return sb.toString();
    }
    
    @Override
    public String getEpocaHistorica() {
        return epocaHistorica.toString();
    }
    
    
    
    
    
    
}
