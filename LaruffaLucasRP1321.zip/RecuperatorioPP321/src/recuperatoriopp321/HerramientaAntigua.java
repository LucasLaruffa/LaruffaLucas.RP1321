
package recuperatoriopp321;

import java.time.LocalDate;


public class HerramientaAntigua extends Hallazgo implements Analizable {
    private String material;
    private int usoProbable;
    private static final int MIN_USO = 0;
    private static final int MAX_USO = 5;

    public HerramientaAntigua( String sitioHallazgo, LocalDate fechaDescubrimiento, int estadoConservacion,String material, int usoProbable) {
        super(sitioHallazgo, fechaDescubrimiento, estadoConservacion);
        validarUso(usoProbable);
        validarMaterial(material);
        this.material = material;
        this.usoProbable = usoProbable;
    }

    @Override
    public String analizar() {
        StringBuilder sb = new StringBuilder();
        sb.append("LA HERRAMIENTA HECHA DE ").append(material).append(", ESTA SIENDO ANALIZADA \n");
        return sb.toString();
    }

    @Override
    public String toString() {
        StringBuilder sb = new StringBuilder();
        sb.append(super.toString()).append(" ESTE HALLAZGO ES UNA HERRAMIENTA HECHA DE ").append(material).append(" CON UN USO PROBABLE DE ").append(usoProbable).append("\n");
        return sb.toString();
    }
    
    private void validarUso(int uso){
        if(usoProbable < MIN_USO || usoProbable > MAX_USO){
            throw new IllegalArgumentException("LA HERRAMIENTA HECHA DE " + material + " ESTA MAL CARGADA");
        }
    }
    
    private void validarMaterial(String material){
        if(material == null){
            throw new IllegalArgumentException("HERRAMIENTA CON MATERIAL INVALIDO");
        }
    }
    
    
    
    
    
    
    
    
}


