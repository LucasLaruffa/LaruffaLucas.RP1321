package recuperatoriopp321;

import java.util.ArrayList;
import java.util.List;

public class SistemaGestionArqueologico {

    private String nombre;
    private List<Hallazgo> hallazgos;

    public SistemaGestionArqueologico(String nombre) {
        validarNombre(nombre);
        this.nombre = nombre;
        hallazgos = new ArrayList<>();
    }

    private void validarNombre(String nombre) {
        if (nombre == null) {
            throw new IllegalArgumentException("ERROR EN CARGA DE DATOS DEL SISTEMA");
        }
    }

    public void registrarHallazgo(Hallazgo hallazgo) {
        validarHallazgo(hallazgo);
        if (hallazgos.contains(hallazgo)) {
            throw new HallazgoExistenteException();
        }
        hallazgos.add(hallazgo);
    }

    public String mostrarHallazgos() {
        validarListaHallazgos(hallazgos);
        StringBuilder sb = new StringBuilder();
        for (Hallazgo h : hallazgos) {
            sb.append(h.toString());

        }
        return sb.toString();
    }

    public String ejecutarAnalisis() {
        validarListaHallazgos(hallazgos);
        StringBuilder sb = new StringBuilder();
        sb.append("RECORDAR QUE LAS CONSTRUCCIONES NO SE ANALIZAN, SE RESTAURAN \n");
        for (Hallazgo h : hallazgos) {
            if (h instanceof Analizable a) {
                sb.append(a.analizar());
            }
        }
        return sb.toString();

    }

    public String restaurarHallazgos() {
        validarListaHallazgos(hallazgos);
        StringBuilder sb = new StringBuilder();
        sb.append("RECORDAR QUE LOS FOSILES Y LAS HERRAMIENTAS NO SE TOCAN, SE ANALIZAN \n");
        for (Hallazgo h : hallazgos) {
            if (h instanceof Restaurable r) {
                sb.append(r.restaurar());
            }

        }
        return sb.toString();
    }
    
    public String filtrarPorEpoca(EpocaHistorica eh){
        StringBuilder sb = new StringBuilder();
    
        for (Hallazgo h : hallazgos) {
            if (h instanceof Restaurable r) {
               if(r.getEpocaHistorica().equals(eh.toString())){
                   sb.append(r.toString());
               }
            }
    }
        return sb.toString();
    }

    public String mostrarPorConservacion(int desde, int hasta){
        StringBuilder sb = new StringBuilder();
        for(Hallazgo h : hallazgos){
            if(h.getEstadoConservacion() >= desde && h.getEstadoConservacion()<= hasta){
                sb.append(h.toString());
            }
            
        }
        return sb.toString();
    }
    
    private void validarHallazgo(Hallazgo h) {
        if (h == null) {
            throw new IllegalArgumentException("ERROR EN CARGA DE HALLAZGO");
        }
    }

    private void validarListaHallazgos(List hallazgo) {
        if (hallazgo.isEmpty()) {
            throw new IllegalArgumentException("LISTA DE HALLAZGOS MAL CARGADA");
        }
    }

}
