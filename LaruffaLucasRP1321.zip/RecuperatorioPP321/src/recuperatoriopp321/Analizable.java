
package recuperatoriopp321;


public interface Analizable {
    String analizar();
}
